//
//  ViewController.swift
//  MyColorPickerApp
//
//  Created by Rajbir Kaur on 2020-05-01.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController, ColorTransferDelegate {

    @IBOutlet weak var colorNameLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    func userDidChoose(color: UIColor, withName colorName: String){
        view.backgroundColor = color
        colorNameLbl.text = colorName
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "presentMain" {
             let ColorPickerVc = segue.destination as! ColorPickerVc
            ColorPickerVc.delegate = self
        }
    }
}

