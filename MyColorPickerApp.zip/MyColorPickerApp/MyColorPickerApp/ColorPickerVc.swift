//
//  ColorPickerVc.swift
//  MyColorPickerApp
//
//  Created by Rajbir Kaur on 2020-05-01.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit

class ColorPickerVc: UIViewController {
    var delegate: ColorTransferDelegate? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        
    
    }
    @IBAction func colorBtnWasPressed(sender : UIButton){
        if delegate != nil {
            delegate?.userDidChoose(color: sender.backgroundColor!, withName: sender.titleLabel!.text!)
            self.navigationController?.popViewController(animated: true)
        }
    }
    


}
