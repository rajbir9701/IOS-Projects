//
//  ColorTransferDelegate.swift
//  MyColorPickerApp
//
//  Created by Rajbir Kaur on 2020-05-01.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import Foundation
import UIKit
protocol ColorTransferDelegate{
    func userDidChoose(color: UIColor, withName colorName: String)
}
