//
//  Wage.swift
//  window-shopper
//
//  Created by Rajbir Kaur on 2020-05-08.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import Foundation
class Wage{
    class func getHours(forWage wage: Double, andPrice price: Double)->Int{
        return Int(ceil(price/wage))
    }
}
