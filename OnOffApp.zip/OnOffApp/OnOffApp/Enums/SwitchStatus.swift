//
//  SwitchStatus.swift
//  OnOffApp
//
//  Created by Rajbir Kaur on 2020-05-01.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import Foundation
enum SwitchStatus : Togglable{
    case on, off
    mutating func toggle(){
        switch self {
        case .off:
            self = .on
            case .on:
                       self = .off
        
        }
    }
}
