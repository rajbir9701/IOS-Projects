//
//  ViewController.swift
//  OnOffApp
//
//  Created by Rajbir Kaur on 2020-05-01.
//  Copyright © 2020 Rajbir Kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var btn: UIButton!
    var switchStatus : SwitchStatus = .off
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    
    @IBAction func btnPressed(_ sender: Any) {
        switchStatus.toggle()
        if switchStatus == .off{
            btn.setImage(UIImage(named: "offBtn")!, for: .normal)
            view.backgroundColor = #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1)
            label.text = "🌚OFF🌚"
            label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            
        }
        else{
            btn.setImage(UIImage(named: "onBtn")!, for: .normal)
                      view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                      label.text = "🌝ON🌝"
                      label.textColor = #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1)
        }
        
    }
    

}

